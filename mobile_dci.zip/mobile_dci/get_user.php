<?php
include 'conn.php';

$uid = isset($_GET['uid']) ? $_GET['uid'] : "";



$sql = "SELECT * FROM sys_user";
$query = mysqli_query($cne, $sql);


if ($query) {
	$json = array();
	while ($row = mysqli_fetch_array($query)) {
		array_push($json, array(
			"uid" => $row['uid'],
			"user" => $row['user_name'],
			'usr_pass' => $row['usr_pass']
		));
	}


	if (!empty($json)) {
		echo json_encode($json);
	} else {
		echo json_encode(array('status' => false, 'message' => 'User tidak ditemukan'));
	}
} else {

	echo json_encode(array('status' => false, 'message' => 'Gagal mengeksekusi query', 'error' => mysqli_error($cne)));
}

mysqli_close($cne);
