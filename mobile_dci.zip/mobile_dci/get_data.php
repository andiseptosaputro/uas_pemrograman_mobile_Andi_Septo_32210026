<?php
include 'conn.php';

$uid = "-1";
$userid = "-1";

$sqlm = "SELECT * FROM sys_user ";
$query = mysqli_query($cne, $sqlm);
$json = array();

while ($row = mysqli_fetch_assoc($query)) {
    $json[] = $row;
}

echo json_encode($json);

mysqli_close($cne);
