<?php
include 'conn.php';

$uid = "-1";
$userid = "-1";


$sqlm = "SELECT * FROM sys_user where status_login = 1 ";
$query = mysqli_query($cne, $sqlm);
$json = array();


while ($row = mysqli_fetch_array($query)) {
    array_push($json, array(
        "uid" => $row['uid'],
        "user" => $row['user_name'],
        'status_login'=>$row['status_login']
    ));
}


echo json_encode($json);
mysqli_close($cne);
