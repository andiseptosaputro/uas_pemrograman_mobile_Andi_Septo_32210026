<?php
include 'conn.php';

$data = $_POST;

// Validasi UID
if (!isset($data['uid'])) {
    echo json_encode(array('status' => false, 'message' => 'UID tidak valid atau tidak ditemukan'));
    exit;
}

$uid = $data['uid'];
$newUsername = isset($data['user_name']) ? $data['user_name'] : "";
$newPassword = isset($data['usr_pass']) ? $data['usr_pass']:"";
$newNoHp = isset($data['no_hp']) ? $data['no_hp'] : "";

// Validasi data yang akan diupdate
if (empty($newUsername) && empty($newNoHp)) {
    echo json_encode(array('status' => false, 'message' => 'Tidak ada data yang akan diupdate'));
    exit;
}

// Bangun prepared statement untuk UPDATE
$updateQuery = "UPDATE sys_user SET ";
$paramTypes = "";
$paramValues = array();

if (!empty($newUsername)) {
    $updateQuery .= "user_name = ?";
    $paramTypes .= "s";
    $paramValues[] = $newUsername;
}

if (!empty($newNoHp)) {
    $updateQuery .= (!empty($newUsername) ? ", " : "") . "no_hp = ?";
    $paramTypes .= "s";
    $paramValues[] = $newNoHp;
}
if (!empty($newPassword)) {
    $updateQuery .= (!empty($newPassword) ? ", " : "") . "usr_pass = ?";
    $paramTypes .= "s";
    $paramValues[] = $newPassword;
}

$updateQuery .= " WHERE uid = ?";
$paramTypes .= "s";
$paramValues[] = $uid;

// Jalankan prepared statement untuk UPDATE
$stmt = $cne->prepare($updateQuery);

// Bind parameters
$stmt->bind_param($paramTypes, ...$paramValues);

// Eksekusi prepared statement
$result = $stmt->execute();

if ($result) {
    echo json_encode(array('status' => true, 'message' => 'Data user berhasil diupdate', 'uid' => $uid));
} else {
    echo json_encode(array('status' => false, 'message' => 'Gagal mengupdate data user', 'error' => $stmt->error));
}

$stmt->close();
mysqli_close($cne);
