<?php
include 'conn.php';

// Ambil data username dan password dari body request (dikirimkan melalui metode POST)
$username = isset($_POST['username']) ? $_POST['username'] : "";
$password = isset($_POST['password']) ? $_POST['password'] : "";

$hash_password = md5($password);

// Cek user berdasarkan username
$sql = "SELECT * FROM sys_user WHERE user_name = ?";
$stmt = $cne->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$json = array();

if ($result) {
    // Mengambil hasil query
    $row = $result->fetch_assoc();

    if ($row) {
        if ($row['status_login'] == 1) {
            $json['status'] = array("message" => "User sudah login");
        } else {
            if ($row['login_count'] >= 3) {
                // Jika sudah gagal login sebanyak 3 kali, kirimkan respons khusus
                $json['status'] = array("message" => 'User telah berusaha login 3 kali');
            } else {
                // Jika belum login sebanyak 3 kali, lanjutkan dengan respons login sukses
                if ($hash_password === $row['usr_pass']) {
                    // Password benar, update login status
                    $updateQuery = "UPDATE sys_user SET status_login = 1, date_login = NOW() WHERE user_name = ?";
                    $stmtUpdate = $cne->prepare($updateQuery);
                    $stmtUpdate->bind_param("s", $row['user_name']);
                    $stmtUpdate->execute();

                    $json['data'] = $row;
                    $json['status'] = array("message" => 'Berhasil');
                } else {
                    // Password salah, increment login_count
                    $incrementQuery = "UPDATE sys_user SET login_count = login_count + 1 WHERE user_name = ?";
                    $stmtIncrement = $cne->prepare($incrementQuery);
                    $stmtIncrement->bind_param("s", $row['user_name']);
                    $stmtIncrement->execute();

                    $json['status'] = array("message" => "Password Salah");
                }
            }
        }
    } else {
        // Jika tidak ada hasil, kirimkan pesan bahwa user tidak ditemukan
        $json['status'] = array("message" => "User tidak ditemukan");
    }
} else {
    // Menampilkan pesan kesalahan jika query gagal
    $json['status'] = array("message" => "Error: " . $cne->error);
}

echo json_encode($json);


mysqli_close($cne);
