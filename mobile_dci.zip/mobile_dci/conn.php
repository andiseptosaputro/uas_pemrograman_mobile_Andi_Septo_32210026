<?php
$host = 'localhost';
$user_name = 'root';
$password = '';
$databases = 'mobile_dci';

$cne = mysqli_connect($host,$user_name,$password,$databases);


if(!$cne){
    echo "Connection Failed";
}

?>