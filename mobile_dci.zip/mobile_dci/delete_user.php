<?php
include 'conn.php';


$data = $_POST;

// Validasi UID
if (!isset($data['uid'])) {
    echo json_encode(array('status' => false, 'message' => 'UID tidak valid atau tidak ditemukan'));
    exit;
}

$uid = $data['uid'];

$sql = "DELETE FROM sys_user WHERE uid = '$uid'";
$query = mysqli_query($cne, $sql);

if ($query) {
    echo json_encode(array('status' => true, 'message' => 'User berhasil dihapus', 'uid' => $uid));
} else {
    echo json_encode(array('status' => false, 'message' => 'Gagal menghapus user', 'error' => mysqli_error($cne)));
}

mysqli_close($cne);
