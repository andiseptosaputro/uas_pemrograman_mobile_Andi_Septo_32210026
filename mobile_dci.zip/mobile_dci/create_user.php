<?php
include 'conn.php';

$json = array();

$username = isset($_POST['username']) ? $_POST['username'] : "";
$password = isset($_POST['password']) ? $_POST['password'] : "";
$no_hp = isset($_POST['no_hp']) ? $_POST['no_hp'] : "";

// Validasi form tidak boleh kosong
if (empty($username) || empty($password) || empty($no_hp)) {
  $json = array('status' => false, 'message' => 'Form tidak boleh kosong');
  echo json_encode($json);
  exit;
}

$id = rand(10, 100);

$hash_password = md5($password);

// Pengecekan data duplikat sebelum memasukkan data ke database
$sqlCheckDuplicate = "SELECT * FROM sys_user WHERE user_name = '$username' OR no_hp = '$no_hp'";
$queryCheckDuplicate = mysqli_query($cne, $sqlCheckDuplicate);

if (mysqli_num_rows($queryCheckDuplicate) > 0) {
  $json['status'] = array('status' => false, 'message' => 'Data duplikat ditemukan');
} else {
  $sqlInsert = "INSERT INTO sys_user (uid, user_name, no_hp, usr_pass) VALUES ('$id', '$username', '$no_hp', '$hash_password')";
  $queryInsert = mysqli_query($cne, $sqlInsert);

  if ($queryInsert) {
    $json = array('status' => true, 'message' => 'Berhasil menambahkan data');
  } else {
    $json = array('status' => false, 'message' => 'Gagal menambahkan data', 'error' => mysqli_error($cne));
  }
}

echo json_encode($json);

mysqli_close($cne);
