<?php
include 'conn.php';

// Ambil data UID dari body request (dikirimkan melalui metode POST atau sesuai kebutuhan)
$uid = isset($_POST['uid']) ? $_POST['uid'] : "";

// Validate that UID is provided
if (empty($uid)) {
    $json['status'] = array("message" => 'Uid tidak boleh kosong');
    echo json_encode($json);
    exit; // Terminate the script to prevent further execution
}

// Check if the user is currently logged in
$checkLoginQuery = "SELECT * FROM sys_user WHERE uid = ? AND status_login = 1";
$stmtCheckLogin = $cne->prepare($checkLoginQuery);
$stmtCheckLogin->bind_param("s", $uid);
$stmtCheckLogin->execute();
$resultCheckLogin = $stmtCheckLogin->get_result();

if ($resultCheckLogin->num_rows === 0) {
    $json['status'] = array("message" => 'User belum login');
} else {
    // Update status login menjadi 0
    $updateStatusQuery = "UPDATE sys_user SET status_login = 0, date_logout = NOW() WHERE uid = ?";
    $stmtUpdateStatus = $cne->prepare($updateStatusQuery);
    $stmtUpdateStatus->bind_param("s", $uid);

    if (!$stmtUpdateStatus->execute()) {
        $json['status'] = array("message" => 'Gagal logout');
    } else {
        $json['status'] = array("message" => 'success');
    }
}

echo json_encode($json);

mysqli_close($cne);
